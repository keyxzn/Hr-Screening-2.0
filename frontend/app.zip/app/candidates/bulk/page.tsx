"use client";
import { useState, useRef } from "react";
import AppLayout from "@/components/AppLayout";
import {
  Upload, Download, FileSpreadsheet, CheckCircle, AlertCircle,
  Loader2, X, Zap, Shield, Globe, ArrowRight, Sparkles, Rss
} from "lucide-react";

interface BulkRow { full_name: string; email: string; phone: string; instagram_url: string; twitter_url: string; facebook_url: string; linkedin_url: string; }

const PLATFORMS = [
  { emoji: "📸", label: "Instagram", color: "#e1306c", sub: "AI automated analysis" },
  { emoji: "🐦", label: "Twitter/X", color: "#1d9bf0", sub: "AI automated analysis" },
  { emoji: "👤", label: "Facebook",  color: "#1877f2", sub: "AI automated analysis" },
  { emoji: "💼", label: "LinkedIn",  color: "#0077b5", sub: "AI automated analysis" },
  { emoji: "🔍", label: "Google",    color: "#34a853", sub: "AI automated analysis" },
  { emoji: "📰", label: "News",      color: "#64748b", sub: "AI automated analysis" },
];

export default function BulkPage() {
  const [file, setFile]       = useState<File | null>(null);
  const [preview, setPreview] = useState<BulkRow[]>([]);
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone]       = useState(false);
  const [consent, setConsent] = useState(false);
  const [drag, setDrag]       = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFile(f: File) {
    setFile(f); setError(""); setPreview([]);
    try {
      const XLSX = await import("xlsx");
      const buf  = await f.arrayBuffer();
      const wb   = XLSX.read(buf);
      const ws   = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<BulkRow>(ws);
      if (rows.length === 0) { setError("File kosong atau format tidak sesuai."); return; }
      setPreview(rows.slice(0, 5));
    } catch { setError("Gagal membaca file. Pastikan format sesuai template."); }
  }

  function downloadTemplate() {
    const csv = [
      "full_name,email,phone,instagram_url,twitter_url,facebook_url,linkedin_url",
      "John Doe,john@email.com,+62 812 0000 0000,https://instagram.com/johndoe,https://x.com/johndoe,https://facebook.com/johndoe,https://linkedin.com/in/johndoe",
      "Jane Smith,jane@email.com,+62 813 0001 0001,https://instagram.com/janesmith,tidak ada,https://facebook.com/janesmith,https://linkedin.com/in/janesmith",
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = "template_hr_screening.csv"; a.click();
  }

  async function startBulk() {
    if (!file || !consent) return;
    setLoading(true);
    try {
      const XLSX  = await import("xlsx");
      const buf   = await file.arrayBuffer();
      const wb    = XLSX.read(buf);
      const ws    = wb.Sheets[wb.SheetNames[0]];
      const rows  = XLSX.utils.sheet_to_json<BulkRow>(ws);
      const BASE  = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
      const token = JSON.parse(localStorage.getItem("hr_user") || "{}").token ?? "";
      for (const row of rows) {
        await fetch(`${BASE}/api/v1/candidates/`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
          body: JSON.stringify({ ...row, consent_given: true }),
        });
      }
      setDone(true);
    } catch { setError("Terjadi kesalahan saat upload."); }
    finally { setLoading(false); }
  }

  return (
    <AppLayout>
      <div style={{ minHeight: "100vh", background: "var(--bg)" }}>

        {/* Hero */}
        <div style={{ background: "linear-gradient(135deg,#071a12 0%,#080b14 60%,#0d1527 100%)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}
          className="px-6 py-10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 mb-4">
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase"
                style={{ background: "rgba(0,200,150,0.1)", color: "var(--accent)", border: "1px solid rgba(0,200,150,0.2)" }}>
                <Sparkles size={9} /> Bulk Screening System
              </span>
            </div>
            <h1 className="font-display text-[30px] font-extrabold text-white tracking-tight mb-2">Upload Kandidat Massal</h1>
            <p className="text-slate-400 text-[14px] mb-7 max-w-lg leading-relaxed">
              Upload file CSV atau Excel untuk screening banyak kandidat sekaligus menggunakan AI background checking.
            </p>
            <div className="flex gap-3 flex-wrap">
              <button onClick={downloadTemplate} className="btn-primary"><Download size={13} /> Download Template</button>
              <button onClick={() => inputRef.current?.click()} className="btn-secondary"
                style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", color: "white" }}>
                <Upload size={13} /> Upload Sekarang
              </button>
            </div>
            <div className="flex gap-8 mt-8">
              {[{ v: "4+", l: "Platform Sosmed" }, { v: "AI", l: "Powered" }, { v: "100+", l: "Batch / Upload" }, { v: "CSV", l: "& XLSX" }].map(s => (
                <div key={s.l}>
                  <p className="font-display text-lg font-extrabold leading-none" style={{ color: "var(--accent)" }}>{s.v}</p>
                  <p className="text-[10px] text-slate-500 font-medium mt-0.5">{s.l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-6 py-8">
          {done ? (
            <div className="card p-12 text-center animate-fade-up">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(0,200,150,0.1)" }}>
                <CheckCircle size={28} style={{ color: "var(--accent)" }} />
              </div>
              <h2 className="font-display text-xl font-bold mb-2" style={{ color: "var(--text)" }}>Bulk Screening Dimulai!</h2>
              <p className="text-sm mb-7 max-w-sm mx-auto" style={{ color: "var(--text2)" }}>
                Semua kandidat sedang diproses oleh AI. Pantau progress di halaman Kandidat.
              </p>
              <a href="/candidates" className="btn-primary" style={{ display: "inline-flex" }}>
                Lihat Semua Kandidat <ArrowRight size={13} />
              </a>
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-5">

                {/* Template card */}
                <div className="card p-5 animate-fade-up stagger-1">
                  <div className="flex items-start justify-between mb-5">
                    <div>
                      <h2 className="font-display text-[15px] font-bold" style={{ color: "var(--text)" }}>Download Template</h2>
                      <p className="text-[12px] mt-0.5" style={{ color: "var(--text3)" }}>
                        Tulis <strong style={{ color: "var(--text2)" }}>tidak ada</strong> untuk platform yang tidak dimiliki kandidat.
                      </p>
                    </div>
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ml-3" style={{ background: "rgba(0,200,150,0.1)" }}>
                      <FileSpreadsheet size={16} style={{ color: "var(--accent)" }} />
                    </div>
                  </div>
                  <div className="rounded-xl overflow-hidden mb-4 text-[11px]" style={{ border: "1px solid var(--border)" }}>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr style={{ background: "var(--bg3)", borderBottom: "1px solid var(--border)" }}>
                            {["Full Name", "Email", "Phone", "Instagram", "Twitter/X", "Facebook", "LinkedIn"].map(h => (
                              <th key={h} className="text-left px-3 py-2.5 font-bold whitespace-nowrap text-[10px] tracking-wider"
                                style={{ color: "var(--text3)" }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { n: "John Doe",   e: "john@email.com", p: "+62 812 0000", i: "instagram.com/john", t: "x.com/john",  f: "facebook.com/john", l: "linkedin.com/in/john" },
                            { n: "Jane Smith", e: "jane@email.com", p: "+62 813 0001", i: "instagram.com/jane", t: "tidak ada",   f: "facebook.com/jane", l: "linkedin.com/in/jane" },
                          ].map((r, i) => (
                            <tr key={i} style={{ borderBottom: i === 0 ? "1px solid var(--border)" : "none" }}>
                              <td className="px-3 py-2.5 font-semibold whitespace-nowrap" style={{ color: "var(--text)" }}>{r.n}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.e}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.p}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.i}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: r.t === "tidak ada" ? "var(--text3)" : "var(--text2)", fontStyle: r.t === "tidak ada" ? "italic" : "normal" }}>{r.t}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.f}</td>
                              <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.l}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <button onClick={downloadTemplate} className="btn-primary w-full justify-center">
                    <Download size={13} /> Download CSV Template
                  </button>
                </div>

                {/* Upload card */}
                <div className="card p-5 animate-fade-up stagger-2">
                  <div className="flex items-start justify-between mb-5">
                    <div>
                      <h2 className="font-display text-[15px] font-bold" style={{ color: "var(--text)" }}>Upload File Kandidat</h2>
                      <p className="text-[12px] mt-0.5" style={{ color: "var(--text3)" }}>Upload file Excel atau CSV yang sudah diisi.</p>
                    </div>
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ml-3" style={{ background: "rgba(59,130,246,0.1)" }}>
                      <Upload size={16} className="text-blue-400" />
                    </div>
                  </div>

                  <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden"
                    onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />

                  {!file ? (
                    <div onClick={() => inputRef.current?.click()}
                      onDragOver={e => { e.preventDefault(); setDrag(true); }}
                      onDragLeave={() => setDrag(false)}
                      onDrop={e => { e.preventDefault(); setDrag(false); e.dataTransfer.files[0] && handleFile(e.dataTransfer.files[0]); }}
                      className="rounded-xl p-10 text-center cursor-pointer transition-all"
                      style={{ border: `2px dashed ${drag ? "var(--accent)" : "var(--border)"}`, background: drag ? "rgba(0,200,150,0.04)" : "var(--bg3)" }}>
                      <div className="w-14 h-14 rounded-2xl mx-auto mb-3 flex items-center justify-center"
                        style={{ background: drag ? "rgba(0,200,150,0.15)" : "rgba(0,200,150,0.08)" }}>
                        <Upload size={22} style={{ color: "var(--accent)" }} />
                      </div>
                      <p className="font-display text-[15px] font-bold mb-1" style={{ color: "var(--text)" }}>Drag & Drop File</p>
                      <p className="text-[12px] mb-4" style={{ color: "var(--text3)" }}>Mendukung .csv, .xlsx, dan .xls</p>
                      <button className="btn-secondary" style={{ display: "inline-flex" }}>Pilih File</button>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-center gap-3 p-4 rounded-xl mb-4"
                        style={{ background: "rgba(0,200,150,0.07)", border: "1px solid rgba(0,200,150,0.2)" }}>
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: "rgba(0,200,150,0.15)" }}>
                          <FileSpreadsheet size={18} style={{ color: "var(--accent)" }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-bold truncate" style={{ color: "var(--text)" }}>{file.name}</p>
                          <p className="text-[11px]" style={{ color: "var(--text3)" }}>
                            {(file.size / 1024).toFixed(1)} KB · {preview.length} baris ditampilkan
                          </p>
                        </div>
                        <button onClick={() => { setFile(null); setPreview([]); }} className="p-1.5 rounded-lg transition-colors"
                          style={{ color: "var(--text3)" }}
                          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = "#ef4444"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(239,68,68,0.1)"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = "var(--text3)"; (e.currentTarget as HTMLButtonElement).style.background = ""; }}>
                          <X size={15} />
                        </button>
                      </div>

                      {preview.length > 0 && (
                        <div className="rounded-xl overflow-hidden mb-4 text-[11px]" style={{ border: "1px solid var(--border)" }}>
                          <div className="px-3 py-2 font-bold flex items-center gap-2"
                            style={{ background: "var(--bg3)", color: "var(--text3)", borderBottom: "1px solid var(--border)" }}>
                            <FileSpreadsheet size={11} /> Preview — 5 baris pertama
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full">
                              <thead>
                                <tr style={{ borderBottom: "1px solid var(--border)" }}>
                                  {["Nama", "Email", "HP", "Platform"].map(h => (
                                    <th key={h} className="text-left px-3 py-2 font-bold" style={{ color: "var(--text3)" }}>{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {preview.map((r, i) => {
                                  const platforms = [
                                    r.instagram_url && r.instagram_url !== "tidak ada" && "IG",
                                    r.twitter_url   && r.twitter_url   !== "tidak ada" && "X",
                                    r.facebook_url  && r.facebook_url  !== "tidak ada" && "FB",
                                    r.linkedin_url  && r.linkedin_url  !== "tidak ada" && "in",
                                  ].filter(Boolean);
                                  return (
                                    <tr key={i} style={{ borderBottom: i < preview.length - 1 ? "1px solid var(--border)" : "none" }}>
                                      <td className="px-3 py-2.5 font-semibold" style={{ color: "var(--text)" }}>{r.full_name}</td>
                                      <td className="px-3 py-2.5" style={{ color: "var(--text2)" }}>{r.email}</td>
                                      <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: "var(--text2)" }}>{r.phone}</td>
                                      <td className="px-3 py-2.5">
                                        <div className="flex gap-1 flex-wrap">
                                          {platforms.map(p => (
                                            <span key={p as string} className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                                              style={{ background: "var(--bg3)", border: "1px solid var(--border)", color: "var(--text2)" }}>
                                              {p}
                                            </span>
                                          ))}
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}

                      <div className="rounded-xl p-4 mb-4 cursor-pointer transition-all" onClick={() => setConsent(c => !c)}
                        style={{ background: consent ? "rgba(0,200,150,0.07)" : "var(--bg3)", border: `1.5px solid ${consent ? "rgba(0,200,150,0.3)" : "var(--border)"}` }}>
                        <div className="flex items-start gap-3">
                          <div className="w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 transition-all"
                            style={{ background: consent ? "var(--accent)" : "transparent", border: `2px solid ${consent ? "var(--accent)" : "var(--border)"}` }}>
                            {consent && <span className="text-white text-[10px] font-bold">✓</span>}
                          </div>
                          <p className="text-[12px] leading-relaxed" style={{ color: "var(--text2)" }}>
                            <strong style={{ color: "var(--text)" }}>Pernyataan Consent</strong> — Semua kandidat dalam file ini telah memberikan persetujuan tertulis sesuai{" "}
                            <strong style={{ color: "var(--text)" }}>UU PDP Indonesia</strong>.
                          </p>
                        </div>
                      </div>

                      {error && (
                        <div className="flex items-center gap-2 mb-4 p-3 rounded-xl text-[12px]"
                          style={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)", color: "#ef4444" }}>
                          <AlertCircle size={13} /> {error}
                        </div>
                      )}

                      <button onClick={startBulk} disabled={loading || !consent} className="btn-primary w-full justify-center"
                        style={{ opacity: loading || !consent ? 0.5 : 1, cursor: loading || !consent ? "not-allowed" : "pointer" }}>
                        {loading ? <><Loader2 size={13} className="animate-spin" />Memproses kandidat...</> : <><Zap size={13} />Mulai Bulk Screening</>}
                      </button>
                    </div>
                  )}
                  {error && !file && (
                    <div className="flex items-center gap-2 mt-3 p-3 rounded-xl text-[12px]"
                      style={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)", color: "#ef4444" }}>
                      <AlertCircle size={13} /> {error}
                    </div>
                  )}
                </div>
              </div>

              {/* Right panel */}
              <div className="space-y-5">
                <div className="card p-5 animate-fade-up stagger-1">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Shield size={13} style={{ color: "var(--accent)" }} />
                      <h3 className="font-display text-[13px] font-bold" style={{ color: "var(--text)" }}>AI Screening</h3>
                    </div>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                      style={{ background: "rgba(0,200,150,0.1)", color: "var(--accent)", border: "1px solid rgba(0,200,150,0.2)" }}>
                      Platform dicek
                    </span>
                  </div>
                  <div className="space-y-2">
                    {PLATFORMS.map(p => (
                      <div key={p.label} className="flex items-center gap-3 p-2.5 rounded-xl"
                        style={{ border: "1px solid var(--border)", background: "var(--bg3)" }}>
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ background: `${p.color}18` }}>
                          <span className="text-sm">{p.emoji}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[12px] font-semibold" style={{ color: "var(--text)" }}>{p.label}</p>
                          <p className="text-[10px]" style={{ color: "var(--text3)" }}>{p.sub}</p>
                        </div>
                        <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "var(--accent)" }} />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="card p-5 animate-fade-up stagger-2"
                  style={{ background: "linear-gradient(135deg,#071a12 0%,#0d1527 100%)", border: "1px solid rgba(0,200,150,0.15)" }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Zap size={12} style={{ color: "var(--accent)" }} />
                    <p className="text-[10px] font-bold tracking-widest uppercase" style={{ color: "var(--accent)" }}>AI Insight</p>
                  </div>
                  <h3 className="font-display text-[16px] font-extrabold text-white mb-2">Smart Detection</h3>
                  <p className="text-[12px] text-slate-400 leading-relaxed">
                    AI mendeteksi <strong className="text-slate-300">toxic language</strong>, fraud, hate speech, explicit content, dan professional risk dari semua platform publik secara otomatis.
                  </p>
                  <div className="mt-4 pt-4 flex flex-wrap gap-1.5" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
                    {["Toxic", "Fraud", "Hate Speech", "Violence", "Extremism"].map(tag => (
                      <span key={tag} className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                        style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid rgba(239,68,68,0.2)" }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}